package ${packageName}.exception;

import com.cditer.free.core.exception.BizException;

/**
 * @author ${author}
 * @email  ${email}
 * @create ${currentDate}
 * @comment
 */

public class ${Name}BizException extends BizException {
    public ${Name}BizException() {
        super();
    }

    public ${Name}BizException(String message) {
        super(message);
    }

    public ${Name}BizException(int code, String message) {
        super(code, message);
    }
}
