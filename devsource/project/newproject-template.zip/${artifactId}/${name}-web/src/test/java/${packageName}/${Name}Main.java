package ${packageName};

/**
 * @author ${author}
 * @email  ${email}
 * @create ${currentDate}
 * @comment
 */
public class ${Name}Main {
	public void testApp(){
	}
}