package ${packageName}.autoconfig;

import org.springframework.context.annotation.ImportResource;
import tk.mybatis.spring.annotation.MapperScan;

/**
 * @author ${author}
 * @email  ${email}
 * @create ${currentDate}
 * @comment
 */
@MapperScan(value = {"${packageName}.logical.mapper.*"})
@ImportResource(locations={"data-service-starter-config.xml"})
public class DataServiceAutoConfiguration {
}
