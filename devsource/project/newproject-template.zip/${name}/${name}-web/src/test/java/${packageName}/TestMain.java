package ${packageName};

/**
 * @author ${author}
 * @email  ${email}
 * @create ${currentDate}
 * @comment
 */
public class StudioMain {
	public void testApp(){
	}
}