package ${packageName};

import com.tennetcn.free.swagger.annotations.EnableThinkSwagger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author ${author}
 * @email  ${email}
 * @create ${currentDate}
 * @comment
 */

@SpringBootApplication
@EnableThinkSwagger
public class ${Name}App {
    public static void main(String[] args) {
        SpringApplication.run(${Name}App.class,args);
    }
}
